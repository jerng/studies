module.exports = async ( data ) => {
    
    console.log( `aMiddleware.js` )
    
    return data
} 